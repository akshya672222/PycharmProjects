## Introduction
Project for Course SSW-555 (Agile Methods for Software Development)
This application is a command line program in Python which analyzes a GEDCOM file, reports and stores its findings

## Authors
Chandra Pradyumna Adusumilli
Akshay Sunderwani
Prabhjot Singh
Pranay Bure

## Installation
User who wish to utilize this application must have Python 2.xx installed on their machines.Please visit www.python.org for futher instructions to install Python.This is a command line program so reach the directory via terminal and run the file using python.

## License

This project is owned and maintained by Tyranicangel.
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.