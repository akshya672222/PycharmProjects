Thanks for your interest in contributing to the FiB project

Welcome 👍

This project and its contributors follow the Contributor Convenant 1.2: we treat each other with respect and are committed to a harrassment-free experience for everyone. If you have questions or issues, contact: alan[at]arogi.com.

Use the GitHub Flow :octocat:

Contributors, including assigned collaborators, should follow the GitHub standard workflow (e.g., fork or create a branch, make changes, and issue a pull request). Do not automatically approve your own pull requests.
